package workbench;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	@Autowired
	UserRepository userRepository;
	
	public List<User> getAllUsers(){
		return (List<User>) userRepository.findAll();
	}
	
	public Optional<User> getUser(String username){
		return userRepository.findById(username);
	}
	
	public void addUser(User user) {
		userRepository.save(user);
	}
	
	public void deleteUser(String username) {
		userRepository.deleteById(username);
	}
	
	public boolean validateUser(String username, String password){
		Optional<User> user = userRepository.findById(username);
		if(user.isPresent() && user.get().getPassword().equals(password))
			return true;
		return false;
	}
}
